import {
  TextField,
  FormControl,
  InputLabel,
  MenuItem,
  FormHelperText,
  Select,
} from "@mui/material";
import "../styles/contactus.css";

function Contact() {
  return (
    <div className="macbook-pro-14-2-parent">
      <div className="macbook-pro-14-2">
        <div className="tech-support-call-on-the-compu-wrapper">
          <img
            className="tech-support-call-on-the-compu"
            alt=""
            src="../tech-support-call-on-the-computer.svg"
          />
        </div>
        <div className="submit-button-parent">
          <button className="submit-button">
            <div className="submit">Submit</div>
          </button>
          <TextField
            className="input-field"
            sx={{ width: 427 }}
            color="primary"
            variant="filled"
            multiline
            rows={4}
            maxRows={5}
            placeholder="Description "
            margin="none"
            required
          />
          <TextField
            className="input-field1"
            sx={{ width: 427 }}
            color="primary"
            variant="filled"
            type="text"
            placeholder="Enter Your Name"
            margin="none"
            required
          />
          <FormControl
            className="input-field2"
            sx={{ width: 427 }}
            variant="filled"
            required
          >
            <InputLabel color="primary" />
            <Select color="primary" />
            <FormHelperText />
          </FormControl>
          <div className="name-label">
            <div className="project">Project</div>
          </div>
          <div className="name-label1">
            <div className="name">Name</div>
          </div>
          <div className="name-label2">
            <div className="description">{`Description `}</div>
          </div>
          <p className="were-here-to-container">
            <span className="were-here-to-help-send-us-yo">
              <span>{`We’re here to help! Send us your query via the form below or send us an email at `}</span>
              <span className="helpdeskgstudiocom">helpdesk@gstudio.com</span>
              <span> for any issue you’re facing</span>
            </span>
            <span className="were-here-to-help-send-us-yo">
              <span>&nbsp;</span>
            </span>
          </p>
          <div className="contact-us">Contact Us</div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
